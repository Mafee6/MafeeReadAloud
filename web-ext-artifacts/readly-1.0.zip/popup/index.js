const documentTextBtn = document.querySelector(".document-text");
documentTextBtn.addEventListener("click", async () => {
    const makeItGreen = 'document.body.innerText';

    const executing = browser.tabs.executeScript({
        code: makeItGreen
    });

    executing.then(console.log);
});